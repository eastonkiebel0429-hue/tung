# Sahur Client (Fabric 1.21.11)

A client-side, Tung Tung Tung Sahur-themed starter client mod.

## Included
- Dark wood / burnt-orange Sahur menu (Right Shift)
- Toggle Sahur skin transformation (G)
- Custom 64x64 pixel-art player skin texture
- Fabric 1.21.11 project source and mixin

The transformation swaps the local client player renderer's skin texture while enabled. It keeps the normal Minecraft player model/animations; it does not add a mob or alter server-side gameplay.

## Build a real remapped mod JAR

Requirements: Java 21 and Gradle 8.14.3 or compatible.

From this folder, run:

```bash
gradle build
```

The distributable remapped JAR will be in `build/libs/` (choose the file without `-dev`). Put that JAR in `.minecraft/mods` alongside Fabric API for Minecraft 1.21.11.

## Controls
- `G`: toggle Sahur transformation
- `Right Shift`: open Sahur Client menu

## Note
This workspace was generated with the Fabric 1.21.11 dependency versions. A compiled JAR could not be produced in this environment because the build system was not installed and external downloads are blocked here. Run the build command above on a computer with Java 21 and internet access to resolve Fabric/Gradle dependencies and create the actual JAR.
