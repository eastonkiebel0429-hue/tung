package com.sahur.client.mixin;

import com.sahur.client.SahurClient;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin {
    @Inject(method = "getTextureLocation", at = @At("HEAD"), cancellable = true)
    private void sahurclient$useSahurSkin(AbstractClientPlayer player, CallbackInfoReturnable<ResourceLocation> cir) {
        if (SahurClient.transformed) cir.setReturnValue(SahurClient.SAHUR_SKIN);
    }
}
