package com.sahur.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class SahurMenuScreen extends Screen {
    public SahurMenuScreen() { super(Component.literal("TUNG TUNG TUNG SAHUR CLIENT")); }
    @Override protected void init() {
        int cx = width / 2;
        int top = height / 2 - 42;
        addRenderableWidget(Button.builder(Component.literal(SahurClient.transformed ? "Disable Sahur Form" : "Become Tung Tung Tung Sahur"), b -> {
            SahurClient.toggle(); b.setMessage(Component.literal(SahurClient.transformed ? "Disable Sahur Form" : "Become Tung Tung Tung Sahur"));
        }).bounds(cx - 105, top, 210, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Back to Game"), b -> onClose()).bounds(cx - 105, top + 30, 210, 20).build());
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int cx = width / 2;
        g.fill(0, 0, width, height, 0xA8000000);
        g.fill(cx - 132, height / 2 - 91, cx + 132, height / 2 + 78, 0xEE21150F);
        g.fill(cx - 132, height / 2 - 91, cx + 132, height / 2 - 88, 0xFFFFA52B);
        g.drawCenteredString(font, "TUNG TUNG TUNG", cx, height / 2 - 76, 0xFFFFC15A);
        g.drawCenteredString(font, "SAHUR CLIENT", cx, height / 2 - 60, 0xFFFFFFFF);
        g.drawCenteredString(font, "WOODEN MODE • CLIENT COSMETIC", cx, height / 2 + 26, 0xFFD9A66B);
        g.drawCenteredString(font, "G = Transform     RIGHT SHIFT = Menu", cx, height / 2 + 43, 0xFFBCA58F);
        super.render(g, mouseX, mouseY, delta);
    }
    @Override public boolean isPauseScreen() { return false; }
}
