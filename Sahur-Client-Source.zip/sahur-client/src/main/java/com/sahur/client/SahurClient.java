package com.sahur.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

public final class SahurClient implements ClientModInitializer {
    public static boolean transformed = false;
    public static final ResourceLocation SAHUR_SKIN = ResourceLocation.fromNamespaceAndPath("sahurclient", "textures/entity/sahur_skin.png");
    private static KeyMapping toggleKey;
    private static KeyMapping menuKey;

    @Override public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.sahurclient.transform", GLFW.GLFW_KEY_G, "category.sahurclient"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.sahurclient.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "category.sahurclient"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                transformed = !transformed;
                if (client.player != null) client.player.displayClientMessage(Component.literal(transformed ? "§6§lTUNG TUNG TUNG SAHUR! §7Transformation ON" : "§7Sahur transformation OFF"), true);
            }
            while (menuKey.consumeClick()) client.setScreen(new SahurMenuScreen());
        });
    }

    public static void setTransformed(boolean value) { transformed = value; }
    public static void toggle() { transformed = !transformed; }
}
